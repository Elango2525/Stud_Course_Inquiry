package com.home.home.utils;



public class MyConstant {
    public static final String AUTH = "/api/v1/auth";
    public static final String DEMO = "/api/v1/demo";
    public static final String LOGIN = "/login";
    public static final String REGISTER = "/register";
}
